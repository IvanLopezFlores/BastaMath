// script.js - Juego "Basta" accesible con voz

let isPlaying = false;
let timer;
let timeLeft = 10;
const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

// Array de posibles mensajes (instrucciones del juego)
const instructions = [
    "Di una palabra que empiece con ",
    "Di un animal cuyo nombre empiece con ",
    "Un país que empiece con ",
    "Nombre de mujer que empiece con ",
    "Nombre de hombre que empiece con ",
    "Cosa que empiece con ",
    "Una fruta que empiece con "
];

// Función para leer texto en voz alta
function speakText(text, callback) {
    console.log("Leyendo:", text);
    speechSynthesis.cancel(); // Detiene cualquier otra voz en curso
    let utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-CO";
    utterance.onend = callback;
    speechSynthesis.speak(utterance);
}

// Función para iniciar o reiniciar el juego
function startGame() {
    clearInterval(timer);
    isPlaying = true;
    timeLeft = 10;
    let randomLetter = getRandomLetter();
    document.getElementById("timer").textContent = timeLeft;

    let randomInstruction = instructions[Math.floor(Math.random() * instructions.length)];
    document.getElementById("instruction").innerHTML = `Instrucción: ${randomInstruction} <span id="letter">${randomLetter}</span>`;

    // Evita doble lectura asegurando que solo habla antes de iniciar el temporizador
    speakText(randomInstruction + randomLetter, startTimer);
}

// Función del temporizador que lee los números en voz alta
function startTimer() {
    timer = setInterval(() => {
        if (timeLeft > 0) {
            document.getElementById("timer").textContent = timeLeft; // Primero actualiza la pantalla
            speechSynthesis.cancel(); // Cancela cualquier voz en curso
            speakText(timeLeft.toString()); // Luego habla el número
            timeLeft--; // Finalmente, reduce el tiempo
        } else {
            clearInterval(timer);
            isPlaying = false;
            setTimeout(() => {
                speakText("¡Tiempo agotado!");
            }, 500);
        }
    }, 1000);
}

// Función para pausar el juego
function pauseGame() {
    clearInterval(timer);
    speakText("Pausa de jueces");
    isPlaying = false;
}

// Función para reanudar el juego
function resumeGame() {
    speakText("Cuenta atrás reanudada", startTimer);
}

// Función para obtener una letra aleatoria
function getRandomLetter() {
    return letters[Math.floor(Math.random() * letters.length)];
}

// Evento para detectar teclas
document.addEventListener("keydown", (event) => {
    let key = event.key.toUpperCase(); // Permitir mayúsculas y minúsculas
    
    if (key === "ENTER") {
        startGame();
    } else if (key === "F") {
        pauseGame();
    } else if (key === "J") {
        resumeGame();
    }
});
